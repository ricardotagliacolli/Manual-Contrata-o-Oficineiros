# Instruções de Instalação - Manual de Contratação de Oficineiros

Este documento contém instruções detalhadas para publicar a interface visual do Manual de Contratação de Oficineiros no GitHub Pages.

## Passo a Passo para Publicação no GitHub Pages

### 1. Preparação dos Arquivos

1. Baixe e extraia o arquivo `manual-oficineiros-dist.zip`
2. Você terá uma pasta chamada `dist` com todos os arquivos da interface

### 2. Criar um Repositório no GitHub

1. Acesse [github.com](https://github.com) e faça login
2. Clique no botão "+" no canto superior direito e selecione "New repository"
3. Nomeie o repositório (ex: `manual-oficineiros`)
4. Adicione uma descrição (opcional)
5. Mantenha o repositório como "Public"
6. Clique em "Create repository"

### 3. Upload dos Arquivos

#### Opção 1: Upload pelo Navegador
1. No seu repositório, clique no botão "Add file" e selecione "Upload files"
2. Arraste todos os arquivos da pasta `dist` para a área de upload
3. Adicione uma mensagem de commit como "Primeira versão da interface visual"
4. Clique em "Commit changes"

#### Opção 2: Usando Git (para usuários avançados)
```bash
git clone https://github.com/seu-usuario/manual-oficineiros.git
cd manual-oficineiros
# Copie todos os arquivos da pasta dist para esta pasta
git add .
git commit -m "Primeira versão da interface visual"
git push origin main
```

### 4. Configurar o GitHub Pages

1. No seu repositório, clique na aba "Settings" (ícone de engrenagem)
2. No menu lateral esquerdo, clique em "Pages"
3. Na seção "Source", selecione "Deploy from a branch"
4. No dropdown "Branch", selecione "main" e "/root"
5. Clique em "Save"
6. Aguarde alguns minutos para o GitHub Pages processar seu site

### 5. Acessar o Site Publicado

1. Após alguns minutos, volte à página "Settings > Pages"
2. Você verá uma mensagem com o link do seu site publicado (algo como `https://seu-usuario.github.io/manual-oficineiros/`)
3. Clique no link para acessar seu site publicado
4. Compartilhe este link com todos que precisam acessar o manual

## Observações Importantes

- O GitHub Pages hospeda seu site gratuitamente por tempo indeterminado
- Seu site terá HTTPS habilitado automaticamente para maior segurança
- Você pode compartilhar o link com qualquer pessoa, sem limitações de acesso
- Não há limites de tráfego ou visitantes para seu site

## Suporte

Se precisar de ajuda adicional, consulte a [documentação oficial do GitHub Pages](https://docs.github.com/pt/pages).
