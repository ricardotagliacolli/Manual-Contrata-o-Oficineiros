# Manual de Contratação de Oficineiros - Interface Visual

Interface visual interativa para o Manual de Contratação de Oficineiros - Serviços de Terceiros Pessoa Física.

## Sobre o Projeto

Esta interface transforma o manual de contratação de oficineiros em uma experiência visual interativa, facilitando a compreensão e navegação das informações através de:

- Dashboard com métricas principais
- Gráficos informativos sobre distribuição orçamentária
- Fluxograma do processo de contratação
- Calculadora avançada para valores líquidos
- Templates de documentos para download

## Conteúdo

- **Visão Geral**: Dashboard com métricas principais e gráficos informativos
- **Distribuição**: Detalhamento da divisão orçamentária entre campi e oficinas
- **Processo**: Fluxograma visual e timeline do procedimento de contratação
- **Calculadora**: Ferramenta avançada para cálculo de valores líquidos
- **Documentos**: Templates organizados com checklists visuais
- **Orientações**: Boas práticas e erros comuns a serem evitados

## Instruções para Publicação

### Publicação no GitHub Pages

1. Extraia o conteúdo do arquivo ZIP
2. Faça upload de todos os arquivos para um repositório GitHub
3. Ative o GitHub Pages nas configurações do repositório
4. Seu site estará disponível em `seu-usuario.github.io/nome-do-repositorio`

### Publicação em Servidor Web

Os arquivos são estáticos (HTML, CSS, JavaScript) e podem ser hospedados em qualquer servidor web.

## Tecnologias Utilizadas

- React 18
- Vite
- Tailwind CSS
- Chart.js para visualizações gráficas

## Créditos

Desenvolvido com base no Manual de Contratação de Oficineiros original.
